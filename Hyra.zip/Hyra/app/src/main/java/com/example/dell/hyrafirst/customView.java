package com.example.dell.hyrafirst;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class customView extends BaseAdapter {

    private Context context;
    private  int icons[];
    private int icon_image[];
    private  String desc[];
    private LayoutInflater inflater;

    public customView(Context context,int icons[],String desc[]){
        this.context=context;
        this.icons=icons;
        this.icon_image=icon_image;
        this.desc=desc;
    }
    @Override
    public int getCount() {
        return desc.length;
    }

    @Override
    public Object getItem(int position) {
        return desc[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View gridView=convertView;
        if(convertView==null){
            inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            gridView=inflater.inflate(R.layout.customlayout,null);
        }
        ImageView imageView=gridView.findViewById(R.id.imageView3);
        imageView.setImageResource(icons[position]);
        return gridView;
    }
}
