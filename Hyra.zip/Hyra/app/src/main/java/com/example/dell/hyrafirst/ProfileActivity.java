package com.example.dell.hyrafirst;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class ProfileActivity extends AppCompatActivity {
    ImageView iv;
    TextView nameofseller;
    Button selling;
    Button sold;
    LinearLayout linearLayout;
    LinearLayout linearLayout1;
    ListView listView;
    ListView listView1;
    ArrayList<String> listItems = new ArrayList<String>();
    ArrayList<String> listItems1 = new ArrayList<String>();

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
       // getSupportActionBar().setTitle("");
        // getSupportActionBar().setIcon(R.drawable.ic_back);
        //getActionBar().setDisplayShowTitleEnabled(false);
        iv = (ImageView) findViewById(R.id.imageView2);
        nameofseller = (TextView) findViewById(R.id.textView7);
        selling = (Button) findViewById(R.id.button8);
        sold = (Button) findViewById(R.id.button9);
        listView = (ListView) findViewById(R.id.dynamic);
        listView1 = (ListView) findViewById(R.id.dynamic1);
        linearLayout = (LinearLayout) findViewById(R.id.linearlayout);
        linearLayout.setVisibility(View.GONE);
        linearLayout1 = (LinearLayout) findViewById(R.id.linearlayout1);
        linearLayout1.setVisibility(View.GONE);
        listItems.add("Electronics");
        listItems.add("books");
        listItems1.add("home appliances");
        listItems1.add("cycles");
        listItems1.add("camera");
        listView.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listItems));
        listView1.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listItems1));
        selling.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linearLayout.setVisibility(View.VISIBLE);
                linearLayout1.setVisibility(View.GONE);
            }
        });
        sold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linearLayout1.setVisibility(View.VISIBLE);
                linearLayout.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if(id==android.R.id.home){
            this.finish();
        }
        return super.onOptionsItemSelected(item);
    }
}