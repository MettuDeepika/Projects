package com.example.dell.hyrafirst;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DescriptionActivity extends AppCompatActivity {
EditText desc;
Button savethedesc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_description);
        desc=(EditText)findViewById(R.id.editText12);
        savethedesc=(Button)findViewById(R.id.button15);
        savethedesc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
String t=desc.getText().toString();
if(t.matches("")){
    Toast.makeText(getApplicationContext(), "please enter description of your item  ", Toast.LENGTH_SHORT).show();

}
else{
    Intent intent=new Intent(DescriptionActivity.this,CameraDesActivity.class);
    startActivity(intent);
}
            }
        });
    }
}
