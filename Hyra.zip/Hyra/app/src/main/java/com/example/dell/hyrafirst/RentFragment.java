package com.example.dell.hyrafirst;


import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


/**
 * A simple {@link Fragment} subclass.
 */
public class RentFragment extends Fragment {
    private static final int CAMERA_REQUEST = 1888;
ImageView imageView;
//Intent  intent=Intent.getIntent();

    public RentFragment() {
        // Required empty public constructor
    }

    public void onActivityResult(int reqCode, int resultCode, Intent data){
        if(resultCode== Activity.RESULT_OK){
            Bitmap photo=(Bitmap)data.getExtras().get("data");
            //((ImageView) imageView.findViewById(R.id.image));
            imageView.setImageBitmap(photo);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_rent, container, false);
    }

}
