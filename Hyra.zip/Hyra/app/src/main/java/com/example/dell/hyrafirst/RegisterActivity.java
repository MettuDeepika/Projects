package com.example.dell.hyrafirst;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class RegisterActivity extends AppCompatActivity {
TextView nameofappl;
EditText username;
EditText password;
EditText conpassword;
EditText email;
EditText mobilenumber;
Button register;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getSupportActionBar().hide();
        nameofappl=(TextView)findViewById(R.id.textView3);
        username=(EditText)findViewById(R.id.editText3);
        password=(EditText)findViewById(R.id.editText4);
        conpassword=(EditText)findViewById(R.id.editText5);
        email=(EditText)findViewById(R.id.editText6);
        mobilenumber=(EditText)findViewById(R.id.editText7);
       register=(Button)findViewById(R.id.button3);
       register.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent  intent=new Intent(RegisterActivity.this,MainActivity.class);
               startActivity(intent);
           }
       });
    }
}
