package com.example.dell.hyrafirst;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class SelectedImageActivity extends AppCompatActivity {
ImageView iv;
TextView  nameofseller;
TextView description;
Button profile;
Button location;;
Button makeanoffer;
Button chat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selected_image);
        iv=(ImageView)findViewById(R.id.imageView);
        nameofseller=(TextView)findViewById(R.id.textView5);
        description=(TextView)findViewById(R.id.textView6);
        profile=(Button)findViewById(R.id.button4);
        location=(Button)findViewById(R.id.button5);
        makeanoffer=(Button)findViewById(R.id.button6);
        chat=(Button)findViewById(R.id.button7);
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(SelectedImageActivity.this,ProfileActivity.class);
                startActivity(intent);
            }
        });
    }
}
