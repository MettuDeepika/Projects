package com.example.dell.hyrafirst;


import android.content.Context;


import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;



 public class ImageAdapter extends BaseAdapter {


    private Context context;


    ImageAdapter(Context c) {

        context=c;
    }

     public int getCount(){
        return Thumbid.length;
    }
    public Object getItem(int position){
        return  Thumbid[position];
    }
    @Override
    public long getItemId(int position) {
        return 0;
    }

     @Override
     public boolean hasStableIds() {
         return false;
     }

     @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView electronics;
        ImageView homeappliances;

        if(convertView==null){
            electronics=new ImageView(context);
            electronics.setLayoutParams(new ViewGroup.LayoutParams(900,900));
            electronics.setPadding(20,20,20,20);


            homeappliances=new ImageView(context);
            homeappliances.setLayoutParams(new ViewGroup.LayoutParams(900,900));
            homeappliances.setPadding(50,50,50,50);

        }
        else
        {
            electronics=(ImageView) convertView;
        }
        electronics.setImageResource(Thumbid[position]);
        return electronics;
    }

     @Override
     public int getItemViewType(int position) {
         return 0;
     }

     @Override
     public int getViewTypeCount() {
         return 0;
     }

     @Override
     public boolean isEmpty() {
         return false;
     }

     private Integer[] Thumbid ={
 R.drawable.electronics,
            R.drawable.homeappliances

    };

     @Override
     public boolean areAllItemsEnabled() {
         return false;
     }

     @Override
     public boolean isEnabled(int position) {
         return false;
     }
 }
