package com.example.dell.hyrafirst;


import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.SearchView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;


public class
HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    NavigationView navigationView;
    DrawerLayout drawer;
    Toolbar toolbar;
    GridView gv;
    SearchView se;
    Bitmap bitmap;
    private static final int CAMERA_REQUEST = 1888;

   // private MenuItem searchMenuItem;
    //private FriendListAdapter friendListAdapter;
    final int TAKE_PICTURE = 1;
    final int ACTIVITY_SELECT_IMAGE = 2;
    android.support.v4.app.FragmentTransaction fragmentTransaction;

    FloatingActionButton fab;
    String[] name = {"electronics", "homeappliances", "bicycles", "books", "dresses", "healthcare", "camera", "Sports"};
    int[] imageid = {
            R.drawable.electronics,
            R.drawable.homeappliances, R.drawable.bicycles, R.drawable.books, R.drawable.dresses, R.drawable.ic_local_hospital, R.drawable.ic_camera, R.drawable.sports
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        se = (SearchView) findViewById(R.id.searchView2);
       // CharSequence query = se.getQueryHint();

        getSupportActionBar().setTitle("Hyra");

        fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //  Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                //        .setAction("Action", null).show();
                selectImage();

            }
        });


        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        gv = findViewById(R.id.grid);
        customView cv = new customView(HomeActivity.this, imageid, name);
        gv.setAdapter(cv);
        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch(position){
                    case 0:
                        Intent intent=new Intent(HomeActivity.this,DescriptionActivity.class);
                        startActivity(intent);
                        break;
                    case 1:
                        Intent intent1=new Intent(HomeActivity.this,SelectedImageActivity.class);
                        startActivity(intent1);
                        break;
                }
                Toast.makeText(getApplicationContext(), "" + name[position], Toast.LENGTH_LONG).show();
            }
        });
    }

    public void onActivityResult(int reqCode, int resultCode, Intent data) {
        if (reqCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
            Intent intent = new Intent(HomeActivity.this, CameraDesActivity.class);
            intent.putExtra("BitmapImage",bitmap);
            startActivityForResult(intent, CAMERA_REQUEST);
        }
    }

    private void selectImage() {
        final CharSequence[] options = {"Take photo", "Choose from Gallery", "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
        builder.setTitle("Add Photo");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (options[which].equals("Take photo")) {
                    Intent cameraintent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(cameraintent, TAKE_PICTURE);
                } else if (options[which].equals("Choose from Gallery")) {
                    Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, ACTIVITY_SELECT_IMAGE);
                } else if (options[which].equals("Cancel")) {
                    dialog.dismiss();
                }


            }
        });
        builder.show();

    }


    @Override
    public void onBackPressed() {
        drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater inflater = getMenuInflater();
        getMenuInflater().inflate(R.menu.home, menu);
        return true;


        // @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        //      int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        //    if (id == R.id.action_settings) {
        //      return true;
        // }

        //    return super.onOptionsItemSelected(item);
        //}

        // @SuppressWarnings("StatementWithEmptyBody")





    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Handle the camera action
        } else if (id == R.id.nav_history) {
            Intent intent = new Intent(HomeActivity.this, SearchActivity.class);
            startActivity(intent);

        } else if (id == R.id.nav_wishitem) {

        } else if (id == R.id.nav_rentitem) {
            Intent intent1 = new Intent(HomeActivity.this, CameraDesActivity.class);
            startActivity(intent1);
           // fragmentTransaction = getSupportFragmentManager().beginTransaction();
            //fragmentTransaction.add(R.id.main_container, new RentFragment());
            //fragmentTransaction.commit();
            //Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            //startActivityForResult(intent, CAMERA_REQUEST);
           //item.setChecked(true);

        } else if (id == R.id.nav_settings) {
            Intent intent = new Intent(HomeActivity.this, SettingsActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_wishlist) {
            Intent intent1 = new Intent(HomeActivity.this, CameraDesActivity.class);
            startActivity(intent1);

        } else if (id == R.id.nav_share) {
            Intent intent2 = new Intent(HomeActivity.this, ProfileActivity.class);
            startActivity(intent2);

        } else if (id == R.id.nav_send) {
            Intent intent = new Intent(HomeActivity.this, SelectedImageActivity.class);
            startActivity(intent);

        }
        drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

}
