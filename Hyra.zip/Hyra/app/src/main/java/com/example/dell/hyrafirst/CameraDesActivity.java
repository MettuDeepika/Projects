package com.example.dell.hyrafirst;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.preference.TwoStatePreference;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class CameraDesActivity extends AppCompatActivity {
ImageView iv;
Spinner sp;
Button Description;
Button price;
Button duration;
Button extncharges;
EditText priceperday;
EditText duartiontime;
EditText chargesperhour;
Button save;

Bitmap bitmap;
ImageView camera;
    private static final int CAMERA_REQUEST = 1888;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera_des);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setUi();
        iv = (ImageView) findViewById(R.id.imageView4);
        sp = (Spinner) findViewById(R.id.spinner);
        Description = (Button) findViewById(R.id.button10);
        price = (Button) findViewById(R.id.button11);
        duration = (Button) findViewById(R.id.button12);
        extncharges = (Button) findViewById(R.id.button13);
        priceperday = (EditText) findViewById(R.id.editText8);
        duartiontime = (EditText) findViewById(R.id.editText9);
        chargesperhour = (EditText) findViewById(R.id.editText10);
        save = (Button) findViewById(R.id.button14);
        camera.setVisibility(View.VISIBLE);
        priceperday.setVisibility(View.GONE);
        duartiontime.setVisibility(View.GONE);
        chargesperhour.setVisibility(View.GONE);

        Description.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CameraDesActivity.this, DescriptionActivity.class);
                startActivity(intent);

            }
        });
        price.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                priceperday.setVisibility(View.VISIBLE);

            }
        });
        duration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                duartiontime.setVisibility(View.VISIBLE);
            }
        });
        extncharges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chargesperhour.setVisibility(View.VISIBLE);
            }
        });
        final ArrayList<String> list = new ArrayList<String>();
        list.add("categories");
        list.add("Homeappliances");
        list.add("Electronics");
        list.add("Health");
        ArrayAdapter<String> adp1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        adp1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(adp1);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getBaseContext(), list.get(position), Toast.LENGTH_SHORT).show();          }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    private void setUi() {
        camera=(ImageView)findViewById(R.id.imageView5);
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, CAMERA_REQUEST);
            }
        });


    }

    public void onActivityResult(int reqCode, int resultCode, Intent data) {
        if (reqCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
            Bitmap photo=(Bitmap)data.getExtras().get("data");
                             camera.setVisibility(View.GONE);
            iv.setImageBitmap(photo);
            Intent intent = new Intent();
           // intent.putExtra("BitmapImage",bitmap);
            //startActivityForResult(intent, CAMERA_REQUEST);

        }
    }
        @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if(id==android.R.id.home){
            this.finish();
        }
        return super.onOptionsItemSelected(item);
    }

    }

